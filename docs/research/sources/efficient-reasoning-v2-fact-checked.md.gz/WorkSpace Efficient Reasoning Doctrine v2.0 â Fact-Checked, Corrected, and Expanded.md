# WorkSpace Efficient Reasoning Doctrine v2.0 — Fact-Checked, Corrected, and Expanded

The original report's core thesis and layered flow are sound and match 2025–2026 best practice, but it contains one stale metric, one misattributed citation, and at least two unverifiable/likely-fabricated GitHub-issue citations — and it almost entirely misses the Chinese-lab architectural innovations (DeepSeek MLA, DeepSeekMoE, disk context caching, sparse attention; Qwen3 MoE) that are now the frontier of token/compute reduction.

## TL;DR
- The original doctrine (MINIMIZE→SELECT→CONSTRAIN→EXECUTE→VERIFY→ESCALATE) is correct and worth preserving; most specific project claims (PicoLM, mini-swe-agent, Aider repo map, DSPy/GEPA, LLMLingua, vLLM `cache_salt`, SGLang, LMCache, Outlines/Guidance, PromptIntern) are **accurate**, but mini-swe-agent's score is stale (now **>74%** on SWE-bench Verified, not 65%) and PromptIntern is misattributed (it is **EMNLP 2024 Findings**, not "ACL Findings 2024").
- Two cautionary citations appear **fabricated/unverifiable**: BitNet issue #600 ("ARM64/NEON incorrect output") and vLLM Semantic Router #2971/#2965 could not be found (the real ARM BitNet issues are *build/compile* errors, not wrong-output bugs). By contrast, **Aider #5058 is real and matches its description exactly**.
- The biggest gap is architectural efficiency from Chinese labs: **DeepSeek MLA** (KV cache cut to ~4–14% of standard multi-head attention), **DeepSeekMoE** with auxiliary-loss-free load balancing and multi-token prediction, **industry-first disk context caching** (Aug 2024, ~90% input-cost savings), **DeepSeek Sparse Attention** (V3.2, 2025), and **Qwen3 MoE** (dense-quality at ~10% active parameters). These belong in any serious efficient-reasoning doctrine.

## Key Findings

### Fact-check scorecard

| Project / Claim | Verdict | Notes |
|---|---|---|
| **PicoLM** ~45 MB runtime for TinyLlama 1.1B, mmap, JSON grammar, <80 KB binary | ✅ Confirmed accurate | README confirms ~45 MB at 2048 context, <80 KB binary, zero deps, JSON grammar constraints. But it is a hobby-scale repo (268 stars / 38 forks), not production infrastructure. |
| **mini-swe-agent** ~100-line core, linear history, minimal scaffolding | ⚠️ Confirmed, number outdated | Still ~100 lines, linear history, `subprocess.run`, bash-only, no tool-calling interface. Now scores **>74% on SWE-bench Verified** (official repo: "scores >74% on the SWE-bench verified benchmark; starts much faster than Claude Code"); the 65% figure was the original July 2025 claim. Adopted by Meta, NVIDIA, IBM, Nebius, Anyscale, Princeton, Stanford. |
| **SWE-agent ACI** (concise, purpose-built views) | ✅ Confirmed, with nuance | Real philosophy; but the mini-swe-agent thesis is that as LMs improved, elaborate agent-computer interfaces became *less* necessary — the doctrine should reflect that shift toward putting the model, not the scaffold, at the center. |
| **Aider repo map** (symbol/dependency graph, ranked, token budget) | ✅ Confirmed accurate | tree-sitter across 130+ languages + personalized **PageRank** over a definition/reference multigraph; binary-search packs top-ranked symbols into a token budget (default 1,024, `--map-tokens`). |
| **DSPy / GEPA optimizer** | ✅ Confirmed accurate | GEPA = "Reflective Prompt Evolution Can Outperform Reinforcement Learning" (arXiv 2507.19457, Agrawal et al., accepted ICLR 2026 Oral). Verbatim: "GEPA outperforms GRPO by 6% on average and by up to 20%, while using up to 35x fewer rollouts... outperforms the leading prompt optimizer, MIPROv2, by over 10%." Available as `dspy.GEPA`. |
| **LLMLingua** up to 20× compression; warns against over-compressing short prompts | ✅ Confirmed accurate | EMNLP'23; LLMLingua-2 (ACL'24 Findings, 3–6× faster) and LongLLMLingua (up to 21.4% RAG gain at ~¼ tokens) exist. Real user issues (dropped final sentence) confirm the over-compression caveat. |
| **vLLM Semantic Router** "Mixture-of-Models" programmable routing | ✅ Confirmed accurate | Envoy `ext_proc` control plane; signal-driven routing (13+ signal families, 13+ selection algorithms). Does not replace operator control over placement/networking/logs/retention. |
| **vLLM** APC, structured output, OpenAI-compatible, `cache_salt` multi-tenant isolation | ✅ Confirmed accurate | `cache_salt` (RFC/Issue #16016) injects a salt into the first block hash so only same-salt requests reuse KV blocks, defeating timing side-channels ("Leaking Secrets from Prefix Caches"). |
| **SGLang** XGrammar default backend, hierarchical KV cache, nondeterminism caveat | ✅ Confirmed accurate | XGrammar is the default grammar backend; HiCache (HiRadixTree) tiers KV across GPU/CPU/disk/remote; dynamic batching + prefix caching can introduce numerical nondeterminism. |
| **LMCache** tiered/persistent KV cache (GPU/CPU/disk/remote) | ✅ Confirmed accurate | arXiv 2510.09665; engine-independent daemon, used by vLLM production-stack for GPU→CPU→disk offload and cross-request reuse. |
| **Outlines / Guidance** constrained decoding; structure not truth | ✅ Confirmed accurate | Guarantees syntactic validity, not semantic correctness; can degrade quality by distorting the token distribution (Park et al., NeurIPS 2024; ASAp correction). |
| **BitNet** ternary 1.58-bit; CPU speed/energy gains | ✅ Tool + headline claims confirmed | 1.37–5.07× on ARM, 2.37–6.17× on x86; energy −55.4% to −82.2%. BitNet-b1.58-2B-4T (4T tokens) is real; official GPU kernel (May 2025) and CPU optimization (Jan 2026) shipped. |
| **BitNet issue #600** ("ARM64/NEON incorrect output," Aug 2026) | ❌ Unverifiable / likely fabricated | Could not confirm #600 exists. Real ARM BitNet issues (#185, #74, #324) are **compile/build** errors (NEON type mismatches, kernel setup), **not** wrong-output correctness bugs. Do not cite as evidence. |
| **PromptIntern** >90% token cut, 4.2× faster, 88.3% cheaper (NL2Code); accuracy gap vs k-shot acknowledged | ⚠️ Numbers accurate, citation wrong | Verbatim from ACL Anthology (Zou et al., **Findings of EMNLP 2024**, pp. 10288–10305; DOI 10.18653/v1/2024.findings-emnlp.602; arXiv 2407.02211): "reduces input tokens by more than 90%, accelerates inference by 4.2 times, and reduces monetary inference costs by 88.3%." OpenReview reports a wider 67–90% token / 39–90% cost / 1.1–5.1× range across tasks. |
| **Aider #5058** (architect-mode prompt-injection handoff) | ✅ Confirmed exactly | Real, **OPEN** issue: "Architect mode can turn README prompt injection into committed backdoored code." A poisoned README's hidden "ARCHITECT OVERRIDE" flows via `editor_coder.run(..., preproc=False)` into committed malicious code — a genuine trust-boundary bug. |
| **vLLM Semantic Router #2971 / #2965** (routing/model-pool contract) | ❌ Unverifiable | Neither could be confirmed; highest confirmed issue was ~#1949. Treat as unsubstantiated. |

### What the original got RIGHT
- The layered doctrine — remove decisions from the LLM with deterministic software; select context aggressively; constrain output structure; verify with something more authoritative than the generator; escalate model strength only on evidence; govern tool execution outside the model — is strongly corroborated across the ecosystem.
- Preferring **native structured output before** third-party constrained decoding is correct: grammar constraints add latency and can degrade quality.
- Treating **LMCache and learned semantic routing as opt-in / P2** (deterministic auditable rules first, shadow-mode learned routing later) is prudent and matches production guidance.
- Correctly noting that **constrained decoding guarantees structure, not factual correctness**.

### What the original got WRONG / OUTDATED / OVERSTATED
- **Stale metric:** mini-swe-agent 65% → **>74%** on SWE-bench Verified.
- **Fabricated/unverifiable citations:** BitNet #600 and Semantic Router #2971/#2965.
- **Misattribution:** PromptIntern is EMNLP 2024 Findings, not ACL Findings.
- **Over-reliance on a hobby demo:** PicoLM is an elegant edge proof-of-concept, not a production serving pillar; the doctrine should mark it "illustrative."
- **US/edge-centric blind spot:** the report misses the architecture-level efficiency frontier now driven largely by Chinese labs.

### Major GAPS the original missed
- **DeepSeek Multi-head Latent Attention (MLA):** low-rank joint KV compression. Per the DeepSeek-V2 paper (arXiv 2405.04434), MLA needs KV cache equal to only **~14% (small MoE) or ~4% (large MoE) of standard multi-head attention** — up to ~93% reduction — *while outperforming* MHA. This is the single biggest long-context efficiency lever and is absent from the original.
- **DeepSeekMoE + auxiliary-loss-free load balancing + Multi-Token Prediction (MTP):** DeepSeek-V3 is 671B total / **37B activated per token**; MTP boosts quality and enables speculative decoding.
- **DeepSeek disk context caching:** industry-first automatic disk prefix caching (shipped **Aug 2, 2024**); official docs report first-token latency on a 128K high-reference prompt cut **from 13s to ~500ms** and **up to 90% cost savings**, with cache-hit tokens billed ~10× cheaper — no code changes.
- **DeepSeek Sparse Attention (DSA), V3.2-Exp (Sept 2025):** a "lightning indexer" selects top-K KV blocks (retrieve-then-attend), reducing long-context complexity toward linear with near-identical benchmark quality; DeepSeek-V3.2 (arXiv 2512.02556) extends this.
- **Qwen3 MoE (235B-A22B, 30B-A3B):** MoE base models match Qwen2.5 dense quality using **~10% of active parameters**; Qwen3-30B-A3B outcompetes QwQ-32B with ~10× fewer active params.
- **Provider prompt-caching APIs — the cheapest wins, and they belong at the top of the doctrine:** Anthropic (official: "reduces costs by up to 90% and reduces latency by up to 85% for long prompts"; cache reads at 10% of base input price, writes +25%); OpenAI automatic caching (~50% off, default for prompts >1,024 tokens); DeepSeek automatic disk cache.
- **Speculative decoding** (MTP-driven, EAGLE-family) as a standard latency lever.
- **SGLang HiCache + external KV stores** (DeepSeek 3FS, Mooncake): reported ~56–84% TTFT reductions in long multi-turn/agent workloads (LMSYS blog — workload-specific).

## Details

### The corrected doctrine: MINIMIZE → SELECT → CONSTRAIN → EXECUTE → VERIFY → ESCALATE

The original flow is preserved because it maps cleanly onto where the real wins are. The essential correction is to elevate **architecture-level efficiency (MLA, MoE, sparse attention, caching) to a first-class layer** rather than an afterthought, and to add an explicit **security boundary at agent handoffs**.

**Engineering Laws (v2.0)** — revised from the original 15:

| # | Law | Verified basis |
|---|---|---|
| 1 | Remove every decision from the LLM that deterministic code can make. | mini-swe-agent minimalism (>74% SWE-bench Verified with ~100 lines); Aider deterministic PageRank map. |
| 2 | Cache the reusable prefix before optimizing anything else — it is the highest-ROI, lowest-risk win. | Anthropic ≤90% cost / ≤85% latency; OpenAI auto ~50%; DeepSeek disk cache (13s→0.5s TTFT on 128K). |
| 3 | Select context; never dump it. Rank and fit to an explicit token budget. | Aider tree-sitter + PageRank; LLMLingua-2 (with anti-over-compression caveat). |
| 4 | Compress the KV cache at the architecture level, not just the app level. | DeepSeek MLA (KV → ~4–14% of MHA); DSA top-K sparse attention. |
| 5 | Activate only the parameters you need (sparse MoE) when self-hosting. | DeepSeekMoE 37B/671B; Qwen3 MoE ~10% active ≈ dense quality. |
| 6 | Constrain structure at decode time; never trust free-form formatting. | vLLM structured output; XGrammar (SGLang default); Outlines/Guidance. |
| 7 | Verify important results with something more authoritative than the generator. | Constrained decoding guarantees syntax, not semantics (Park et al., NeurIPS 2024); add tests/validators/retrieval grounding. |
| 8 | Escalate model strength only on evidence; route small-first. | vLLM Semantic Router; project-reported 8B+memory recovering most of a 235B model's task quality at ~96% lower cost (validate per workload). |
| 9 | Governance and tool execution live outside the model. | Envoy `ext_proc` router; operator retains placement/logs/retention. |
| 10 | Treat prompt-injection across agent handoffs as a hard security boundary. | Aider #5058: README injection → committed backdoor via architect→editor handoff bypassing preprocessing. |
| 11 | Prefer native / first-party features before third-party layers. | vLLM native structured output before Outlines; `cache_salt` before bespoke isolation. |
| 12 | Measure before deploying optional infra (KV offload, learned routing). | LMCache/HiCache as P2; shadow-mode routing first. |
| 13 | Pin numerics where determinism matters. | SGLang: dynamic batching + prefix caching → numerical nondeterminism. |
| 14 | Golden-output test any exotic quantization on the target hardware. | BitNet ternary gains real; ARM build issues real (#185, #74, #324) — test per architecture. |
| 15 | Internalize recurrent prompts into weights only for stable, high-volume tasks. | PromptIntern (EMNLP 2024 Findings): >90% token cut, 4.2× faster, 88.3% cheaper on NL2Code — with an accepted accuracy gap vs k-shot. |

### Recommended architecture stack (v2.0)
- **Serving engine:** vLLM is a defensible default (Automatic Prefix Caching, native structured output, `cache_salt` isolation, OpenAI-compatible, day-0 support for new models including DeepSeek-V3.2). SGLang is a co-equal choice where XGrammar-default constrained decoding and HiCache hierarchical KV are priorities. The original's "vLLM over SGLang for now" is reasonable but should be framed as a close call, not a settled verdict — both now support the newest sparse-attention models.
- **Caching (do this first):** enable APC everywhere; structure prompts prefix-stable (static system/tools/context first, variable query last). For hosted APIs, exploit Anthropic/OpenAI/DeepSeek caching directly. Add LMCache/HiCache tiering only after measuring KV reuse.
- **Context selection:** Aider-style ranked maps into a hard token budget; add prompt compression (LLMLingua-2) only for genuinely long prompts — never short ones.
- **Structured output:** native JSON-schema first; XGrammar for recursive grammars; always keep a downstream semantic validator (structure ≠ truth).
- **Routing:** deterministic, auditable rules first; add learned semantic routing in shadow mode; small-model-first with evidence-based escalation.
- **Model choice when self-hosting:** prefer **MLA + MoE** families (DeepSeek-V3/V3.2, Qwen3 MoE) for the compute/quality frontier; reserve ternary/1-bit (BitNet) for edge/CPU with per-architecture golden tests.

## Recommendations
1. **Immediately (days):** enable prefix/prompt caching on every model path and restructure prompts for cacheability — the highest ROI, lowest risk. Correct the stale/misattributed facts (mini-swe-agent **>74%**; PromptIntern = **EMNLP 2024 Findings**) and delete the unverifiable BitNet #600 and Semantic Router #2971/#2965 citations.
2. **Near-term (weeks):** implement ranked context selection with a hard token budget; adopt native structured outputs plus a downstream semantic validator; stand up deterministic routing with logging to feed a future shadow-mode learned router.
3. **Mid-term (quarter):** if self-hosting, migrate to an MLA+MoE model family; benchmark KV-cache reuse to decide on LMCache/HiCache; pilot speculative decoding (MTP/EAGLE) for latency.
4. **Security gate (always-on):** treat all content entering an agent handoff (READMEs, retrieved docs, tool output) as untrusted and re-apply input preprocessing at every hop (per Aider #5058). CI gates: golden-output tests for any quantized/edge model per architecture; determinism pins where required.
- **Thresholds that change the plan:** measured prefix cache-hit rate <~30% → redesign prompts before buying infra; high KV reuse and TTFT-bound → deploy tiered KV; shadow-mode router misroutes above tolerance → keep deterministic rules.

## Caveats
- Vendor/pricing figures (Anthropic/OpenAI/DeepSeek caching discounts, DeepSeek V4 rates) change frequently — treat specific percentages as time-stamped, not permanent.
- Some efficiency claims come from project blogs/vendor docs (e.g., ~96% cost recovery via routing, HiCache TTFT reductions, DeepSeek's 13s→0.5s figure) and are workload-specific; validate on your own traffic.
- BitNet #600 and Semantic Router #2971/#2965 could not be fetched directly due to tooling limits; "unverifiable" reflects both absence of evidence and that limitation — but the burden of proof rests on the original report, and the analogous real issues contradict its characterization.
- The uploaded document was not accessible in Drive; this analysis is based on the detailed claims summary provided in the task. Where the original's wording of a claim differs from what was summarized, re-verify against the source before publishing.