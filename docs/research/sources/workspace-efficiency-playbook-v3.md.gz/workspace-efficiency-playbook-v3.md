# WorkSpace Efficiency Playbook v3.0 — Sổ tay kỹ thuật áp dụng ngay (không cần nghiên cứu thêm)

> Định dạng: bảng số liệu + tham số chính xác + đoạn code mẫu. Mỗi mục có nguồn. Bỏ hết lý thuyết trừu tượng — đây là danh sách "làm gì, với tham số gì, theo thứ tự nào".

---

## 0. Thứ tự triển khai (ROI giảm dần)

| Bước | Việc làm | Công sức | ROI |
|---|---|---|---|
| 1 | Bật prompt caching (API bên ngoài hoặc `--enable-prefix-caching` nếu tự host) | ~1 giờ | Cao nhất — giảm 50–90% chi phí input, không đổi chất lượng |
| 2 | Cấu trúc lại prompt: phần **cố định** (system prompt, tool schema, few-shot) đặt **đầu**, phần **biến đổi** (câu hỏi, dữ liệu camera/branch cụ thể) đặt **cuối** | ~2–4 giờ | Cao — quyết định cache có "trúng" hay không |
| 3 | Structured output (JSON schema) thay vì parse text tự do | ~1 ngày | Cao — loại bỏ lỗi parse, giảm retry |
| 4 | Đo cache-hit rate 1 tuần, điều chỉnh breakpoint | liên tục | Trung bình |
| 5 | Nếu tự host: quantize model xuống AWQ-INT4 hoặc GGUF Q4_K_M cho các model 7B–32B chạy edge | 1–2 ngày | Cao cho fleet biên (edge) |
| 6 | Prompt compression (LLMLingua-2) — **chỉ** khi context > ~3.000–4.000 token | vài giờ | Trung bình, có rủi ro nếu prompt ngắn |
| 7 | Model routing nhỏ→lớn (small-first cascade) | 1 tuần | Cao về lâu dài, cần dữ liệu đánh giá trước |

---

## 1. Prompt/Context Caching — tham số chính xác

### 1.1 Anthropic (Claude API)

| Tham số | Giá trị |
|---|---|
| Cơ chế | Đánh dấu `cache_control` trên block muốn cache (tools → system → messages, theo đúng thứ tự này) |
| TTL mặc định | 5 phút, tự làm mới mỗi lần cache được đọc |
| TTL mở rộng | 1 giờ (trả phí ghi cao hơn) |
| Chi phí ghi (write) | 5 phút: **1.25×** giá input thường; 1 giờ: **2.0×** |
| Chi phí đọc (read/cache hit) | **0.10×** giá input thường (giảm ~90%) |
| Ngưỡng tối thiểu để cache hoạt động hiệu quả | ~1.024 token trở lên |
| Số breakpoint tối đa | Tối đa **4** breakpoint tường minh — dùng khi có nhiều phần thay đổi tốc độ khác nhau (system prompt ổn định hàng tuần / tài liệu context đổi hàng ngày / câu hỏi đổi mỗi lần) |
| Token cache không tính vào rate limit | `cache_read_input_tokens` không tính vào ITPM — lợi ích kép |
| Quy tắc hòa vốn | Cache trả tiền ngay từ lần đọc đầu tiên vì write 1.25× < chi phí gửi lại toàn bộ input mỗi lần; hòa vốn nhanh hơn nếu prefix được đọc lại nhiều lần trong TTL |

**Code pattern:**
```python
messages=[{
  "role": "system",
  "content": [
    {"type": "text", "text": SYSTEM_PROMPT_ON_DINH,
     "cache_control": {"type": "ephemeral"}}
  ]
}, ...]
```
Nguồn: platform.claude.com/docs/prompt-caching; xác nhận qua nhiều bài kỹ thuật 2026 (respan.ai, jobsbyculture.com, technspire.com) — mức giảm 90%/85% và ngưỡng 1.024 token khớp nhất quán giữa các nguồn.

### 1.2 OpenAI

| Tham số | Giá trị |
|---|---|
| Cơ chế | **Tự động**, không cần sửa code |
| Ngưỡng tối thiểu | 1.024 token, tăng dần theo bước 128 token |
| Chi phí đọc | **0.5×** giá input thường (giảm 50%) |
| Chi phí ghi | Miễn phí |

### 1.3 DeepSeek — Context Caching on Disk

| Tham số | Giá trị |
|---|---|
| Cơ chế | Tự động, cache trên đĩa (không phải RAM) — khác biệt kỹ thuật so với Anthropic/OpenAI |
| Hiệu quả thực tế | Time-to-first-token trên prompt 128K giảm từ **13 giây → ~500ms**; tiết kiệm đến **90%** chi phí |
| Yêu cầu | Khớp prefix chính xác từng token |

Nguồn: api-docs.deepseek.com/news/news0802 — **đặc biệt liên quan** cho hệ thống nhiều branch/camera nếu dùng DeepSeek API cho các tác vụ suy luận không cần Claude/GPT.

### 1.4 vLLM (tự host) — Automatic Prefix Caching

| Flag | Ý nghĩa |
|---|---|
| `--enable-prefix-caching` | Bật APC (mặc định bật sẵn trên V1 engine) |
| `--block-size 16` (mặc định) | Kích thước block để hash — có thể chỉnh 32 tùy phần cứng |
| `--prefix-caching-hash-algo sha256_cbor` | Dùng bản này nếu cần hash tái lập được giữa các môi trường (khuyến nghị cho fleet nhiều máy) |
| `cache_salt` (field trong request JSON) | Cô lập cache theo nhóm tin cậy — **quan trọng cho hệ thống multi-branch/multi-tenant**: đặt salt riêng theo branch_id để tránh rò rỉ dữ liệu giữa các chi nhánh qua side-channel timing, đồng thời vẫn cho phép reuse cache trong cùng branch |

**Code pattern (multi-branch cache isolation):**
```json
{
  "messages": [...],
  "cache_salt": "branch_042"
}
```
Nguồn: docs.vllm.ai/design/prefix_caching; RFC #16016 (github.com/vllm-project/vllm/issues/16016) — mô tả rõ nguy cơ side-channel và lý do cần salt theo nhóm.

### 1.5 Ứng dụng trực tiếp cho hệ thống 97 chi nhánh / nhiều camera

Đây là kịch bản **prefix dùng chung, phần đuôi khác nhau** — đúng bài toán APC được thiết kế để giải:
- Đặt system prompt + tool schema + hướng dẫn xử lý YOLO/OpenCV **giống nhau tuyệt đối theo từng byte** cho mọi request (không chèn timestamp/branch_id vào đầu prompt).
- Đặt `cache_salt` = nhóm tin cậy (ví dụ: theo cụm branch dùng chung 1 GPU server) để KV cache dùng chung trong nhóm nhưng cô lập giữa các nhóm không tin cậy nhau.
- Dữ liệu riêng của từng camera/branch (bounding box, frame metadata, câu hỏi cụ thể) đặt **cuối cùng** trong prompt.
- Nếu 1 GPU server phục vụ nhiều branch cùng lúc: prefix hệ thống dùng chung → 1 lần tính KV, tái sử dụng cho toàn bộ batch request đến cùng server. Đây chính là lợi ích lớn nhất của APC ở quy mô fleet.

---

## 2. Context/Token Budget — con số cụ thể

| Thành phần | Ngân sách tham khảo (thực tế) |
|---|---|
| Aider repo map mặc định | `--map-tokens 1024` (có thể chỉnh) |
| Aider thuật toán chọn context | tree-sitter (130+ ngôn ngữ) + **PageRank cá nhân hóa** trên đồ thị định nghĩa/tham chiếu → binary search để vừa đúng ngân sách token |
| Ngưỡng dùng nén prompt | Chỉ áp dụng khi prefix > ~2.000–3.000 token; dưới ngưỡng này, overhead của việc gọi model nén lớn hơn lợi ích |

### LLMLingua-2 — code pattern chính xác

```python
# pip install llmlingua
from llmlingua import PromptCompressor

llm_lingua = PromptCompressor()  # dùng model LLMLingua-2 mặc định

# Cách 1: theo tỉ lệ nén (rate = tỉ lệ token giữ lại)
compressed = llm_lingua.compress_prompt(context, rate=0.5)

# Cách 2: theo số token đích (ưu tiên hơn rate)
compressed = llm_lingua.compress_prompt(
    context,
    target_token=3000,
    force_tokens=["!", ".", "?", "\n"],  # giữ nguyên các token quan trọng cho cấu trúc
    drop_consecutive=True,
)
```
- Tốc độ: LLMLingua-2 nhanh hơn LLMLingua gốc **3–6×**.
- Cảnh báo: **không** nén prompt vốn đã ngắn — tài liệu chính thức và các báo cáo thực tế xác nhận nén quá mức có thể làm rớt câu/ý quan trọng.
- LongLLMLingua: cải thiện chất lượng RAG **+17.1%** ở mức nén 4× (không chỉ giảm chi phí mà còn tăng chất lượng nhờ giảm hiện tượng "lost in the middle").

Nguồn: github.com/microsoft/LLMLingua (DOCUMENT.md, prompt_compressor.py), llmlingua.com.

---

## 3. Structured Output — code pattern chính xác

### vLLM (API hiện hành, thay thế `guided_json` cũ)
```python
completion = client.chat.completions.create(
    model="Qwen/Qwen2.5-3B-Instruct",
    messages=[...],
    extra_body={"structured_outputs": {"json": json_schema}},
    # backend cụ thể (tùy chọn):
    # extra_body={"structured_outputs": {"json": json_schema, "backend": "xgrammar:no-fallback"}}
)
```
- Tham số cũ `guided_json` đã **deprecated**, chuyển sang `structured_outputs.json`.
- Overhead: vLLM V1 gần như không đáng kể ở batch nhỏ, nhưng có **giảm hiệu năng rõ rệt tại batch size ≥8** do sinh mask tuần tự (không overlap với GPU).
- **SGLang xử lý tốt hơn ở batch lớn**: overlap việc sinh mask (CPU) với suy luận (GPU) → gần bằng hiệu năng baseline. Nếu hệ thống chạy nhiều request song song (nhiều camera cùng lúc), cân nhắc SGLang thay vì vLLM cho phần structured output.
- **Cảnh báo quan trọng**: JSON Pass Rate (đúng cú pháp) có thể >84% nhưng Value Accuracy (đúng nội dung) chỉ ~80%. Constrained decoding đảm bảo *cú pháp*, không đảm bảo *sự thật* — vẫn cần validator riêng.

Nguồn: docs.vllm.ai/features/structured_outputs; blog.squeezebits.com (benchmark vLLM vs SGLang); arxiv 2604.25359 (Structured Output Benchmark).

---

## 4. Quantization cho triển khai biên (edge) — áp dụng trực tiếp cho fleet 97 chi nhánh

Đây là phần **quan trọng nhất** cho hệ thống của bạn — dùng số liệu ở quy mô 7B–32B (không phải quy mô 671B không áp dụng được).

| Phương pháp | Mức giữ độ chính xác | Khi nào dùng |
|---|---|---|
| **FP8 (W8A8)** | Giảm trung bình chỉ **0.2%** so với BF16 | Nếu phần cứng hỗ trợ (Hopper/Blackwell) — chọn đầu tiên nếu có |
| **GPTQ-INT8 (W8A16)** | Giảm **0.8%** | Lựa chọn an toàn khi không có FP8 |
| **AWQ-INT4** | Giảm **1.8%** trung bình | **Khuyến nghị mặc định cho triển khai biên VRAM hạn chế** — tốt hơn GPTQ-INT4 ở hầu hết benchmark |
| **GPTQ-INT4** | Giảm **2.7%** | Dùng khi không có bản AWQ sẵn (nhiều model phổ biến có sẵn AWQ cộng đồng) |
| **BNB-NF4** | Giảm **6.9%** — rớt nhiều nhất | Chỉ dùng cho thử nghiệm nhanh, không khuyến nghị production |
| **GGUF Q4_K_M / Q5_K_M** (llama.cpp/Ollama) | Giữ **95–98%** độ chính xác gốc (đo trên họ Qwen2.5 7B–32B) | Phù hợp cho máy chủ chi nhánh CPU-only hoặc GPU nhỏ (RTX 4060/4070) |

**Quy tắc cụ thể theo tác vụ:**
- Tránh INT4 cho tác vụ **toán/code/suy luận phức tạp** — độ lệch dễ nhận thấy nhất ở đây.
- Với tác vụ **phân loại/trích xuất cấu trúc** (đúng use-case computer vision + báo cáo của bạn — ví dụ phân loại sự kiện camera, trích xuất bounding box thành JSON), AWQ-INT4/GPTQ-INT8 gần như không mất chất lượng.
- **Qwen2.5 là họ model chịu quantize tốt nhất** trong các benchmark hiện có (7B/14B/32B) — ưu tiên nếu chọn model self-host cho fleet edge.
- Phần cứng gợi ý: GPU 24GB (RTX 4090-class) → AWQ-INT4/GGUF cho model 13B–30B; GPU nhỏ hơn → GGUF Q4_K_M qua llama.cpp/Ollama cho 7B.

**Code pattern (vLLM + AWQ):**
```bash
vllm serve TheBloke/Qwen2.5-7B-Instruct-AWQ --quantization awq
```

Nguồn: aclanthology.org/2025.emnlp-main.479 (benchmark long-context 5 phương pháp × 5 model, số liệu % giảm chính xác nêu trên); ionio.ai/blog/llm-quantize-analysis (Qwen2.5 7B/14B/32B, GGUF Q4_K_M/Q5_K_M 95–98%); arxiv 2306.00978 (AWQ gốc, edge single-batch memory-bound).

---

## 5. Ngưỡng/luật cứng nên đưa vào code (hardcode làm engineering rule)

| Luật | Ngưỡng | Hành động |
|---|---|---|
| Cache hit rate thấp | < 30% sau 1 tuần đo | Thiết kế lại prompt (kiểm tra thứ tự cố định/biến đổi) trước khi mua thêm hạ tầng cache |
| Context dài | > 2.000–3.000 token | Cân nhắc LLMLingua-2; dưới ngưỡng này — không nén |
| Prompt cache Anthropic | < 1.024 token | Không cache được — tối ưu hướng khác |
| Batch structured-output trên vLLM | ≥ 8 request đồng thời | Cân nhắc chuyển sang SGLang cho phần này |
| Quantization cho tác vụ suy luận/toán | — | Không dùng INT4, tối thiểu INT8/FP8 |
| Quantization cho phân loại/trích xuất | — | AWQ-INT4/GGUF Q4_K_M an toàn |
| Multi-branch cache | luôn luôn | Gắn `cache_salt` theo nhóm tin cậy, không bao giờ dùng chung salt giữa các nhóm không tin cậy nhau |

---

## Ghi chú về độ tin cậy số liệu
- Số liệu giá/TTL của Anthropic/OpenAI/DeepSeek thay đổi theo thời gian — các trích dẫn trên phản ánh tài liệu chính thức và bài viết kỹ thuật giữa 2026; kiểm tra trang pricing trực tiếp trước khi build hệ thống tính phí.
- Số liệu quantization benchmark lấy từ ACL/EMNLP 2025 benchmark chính thức trên Llama-3.1 và Qwen-2.5 — có thể không khớp 100% với model khác nhưng xu hướng tương đối (FP8 > GPTQ-int8 > AWQ-int4 > GPTQ-int4 > BNB-nf4) là nhất quán qua nhiều nguồn độc lập.
- Phần "cache_salt cho multi-branch" là suy luận kỹ thuật hợp lý từ tài liệu vLLM chính thức, chưa có case study công khai đúng y hệt kịch bản "97 chi nhánh camera" — nên thử nghiệm trên 2–3 branch trước khi áp dụng toàn fleet.
